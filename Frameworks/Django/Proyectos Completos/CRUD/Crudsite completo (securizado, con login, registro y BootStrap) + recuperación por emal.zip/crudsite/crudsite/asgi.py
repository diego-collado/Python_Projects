import os # Importa el módulo estándar os (variables de entorno y otras utilidades del sistema operativo)
from django.core.asgi import get_asgi_application # Importación de función crea y devuelve la aplicación ASGI (el “callable” que entiende un servidor ASGI)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'crudsite.settings') # Define por defecto la variable de entorno
application = get_asgi_application() # Crea el callable ASGI y lo asigna a application