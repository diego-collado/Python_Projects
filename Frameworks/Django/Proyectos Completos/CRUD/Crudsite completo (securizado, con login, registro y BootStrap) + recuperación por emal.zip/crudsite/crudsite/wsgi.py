import os # módulo que permite interactuar con el sistema operativo (leer o modificar variables de entorno, acceder a rutas, archivos, etc.

from django.core.wsgi import get_wsgi_application
'''
Crea y devuelve un objeto WSGI (Web Server Gateway Interface), el cual sirve como puente entre Django y el servidor 
web (Apache, etc.)
'''

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'crudsite.settings') # ¿qué settings tengo? con este archivo, se define

application = get_wsgi_application() # el objeto WSGI configurado se guarda en la variable application