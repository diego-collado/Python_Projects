from django.db import models # Importación del módulo de gestión de modelos de la BBDD
from django.conf import settings # Importación de la configuración de Django

# Declaración del modelo Tarea, heredado de models.Model
class Task(models.Model):
    # cómo se gestiona el usuario (comportamientos en borrado, autenticaciones...)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, # dejamos que Django controle el tema de autenticaciones
        on_delete=models.CASCADE, # borrado en cascada, se borra absolutamente todo lo que tenga ese usuario
        related_name='tasks' # todo es relativo a esta App
    )

    # Cómo son los campos y condiciones de los mismos
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    completada = models.BooleanField(default=False)
    creada = models.DateTimeField(auto_now_add=True)
    actualizada = models.DateTimeField(auto_now=True)

    class Meta: # Metadata
        ordering = ['-creada'] # orden por defecto de las consultas. En este caso el orden es DESC
        # nombres legibles desde admin y el resto de UI (User Interface -- la pantalla que ve el usuario)
        verbose_name = 'tarea' 
        verbose_name_plural = 'tareas'

    # Método mágico de Python: representa el texto del objeto, mostrándolo en la UI como título
    def __str__(self):
        return self.titulo