from django.apps import AppConfig # Importación del módulo de configuración de mi App

# Creamos una clase que será la tabla completa de la BBDD
class TareasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tareas'