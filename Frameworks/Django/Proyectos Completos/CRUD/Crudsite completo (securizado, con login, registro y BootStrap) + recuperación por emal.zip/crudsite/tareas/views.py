# ARCHIVO DE VISTAS BASADAS EN CLASES (CBV)

from django.contrib.auth.mixins import LoginRequiredMixin # Restricciones de acceso por autenticación
from django.urls import reverse_lazy # genera la URL inversa, es decir, el "rollback"
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView # Importación de las vistas genéricas
from .models import Task # Importación del modelo Tareas
from .forms import TaskForm # Importación del modelo de formulario (personalizado)

# Vista que muestra la lista de objetos de tipo Tarea
class TaskListView(LoginRequiredMixin, ListView): # aseguramos que el usuario vea unicamente su lista
    model = Task
    template_name = 'tareas/task_list.html' # qué plantilla se va a renderizar al llamar a esta función
    context_object_name = 'tareas' # nombre de las tareas que estarán disponibles para la plantilla

    # Filtrado de tareas para que cada usuario SOLO vea sus propias tareas
    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)
        # self.request.user --> usuario actual autenticado

# Vista que muestra los detalles de un único objeto
class TaskDetailView(LoginRequiredMixin, DetailView):
    model = Task
    template_name = 'tareas/task_detail.html'
    context_object_name = 'tarea'

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

# Vista que muestra el formulario de creación de un nuevo objeto de tipo tarea
class TaskCreateView(LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'tareas/task_form.html'
    success_url = reverse_lazy('tareas:lista') # qué voy a ver cuando termino de crear la tarea... se redirecciona a la lista de tareas

    # El método se ejecutará cuando el formulario sea válido
    def form_valid(self, form):
        form.instance.owner = self.request.user # el propietario es el usuario actual logueado
        return super().form_valid(form) # retorno al guardado "original"

# Vista que muestra el formulario de modificación de un objeto de tipo Tarea
class TaskUpdateView(LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'tareas/task_form.html'
    success_url = reverse_lazy('tareas:lista')

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

# Vista que muestra el formulario de confirmación de eliminación
class TaskDeleteView(LoginRequiredMixin, DeleteView):
    model = Task
    template_name = 'tareas/task_confirm_delete.html'
    success_url = reverse_lazy('tareas:lista')

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)