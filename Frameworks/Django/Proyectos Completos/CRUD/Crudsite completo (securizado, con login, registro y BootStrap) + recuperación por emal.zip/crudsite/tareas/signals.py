# Control de mensajes por parte de Django
from django.contrib.auth.signals import user_logged_in, user_logged_out # mensajes de autenticación
from django.dispatch import receiver # Importación del decorador @receiver que conectará funciones con su respectivo mensaje
from django.contrib import messages # Importación del módulo de gestión de mensajes de Django

@receiver(user_logged_in) # función a ejecutar cada vez que se dispare la señal de login
def show_login_message(sender, user, request, **kwargs):
# modelo_que_envía_la_señal, usuario_que_está_logueado, petición_HTTP, otros_parámetros
    messages.success(request, f"¡¡Bienvenido, {user.username}!! Has iniciado sesión correctamente")
    # Utilizamos el sistema de mensajes de Django

@receiver(user_logged_out) # función a ejecutar cada vez que se dispare la señal de logout
def show_logout_message(sender, user, request, **kwargs):
    messages.info(request, "Acabas de cerrar sesión... ¡¡Hasta pronto!!")