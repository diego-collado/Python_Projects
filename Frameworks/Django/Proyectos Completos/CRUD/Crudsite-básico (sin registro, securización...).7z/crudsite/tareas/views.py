from django.shortcuts import render
from django.urls import reverse_lazy 
# reverse_lazy genera una URL a partir del nombre de la ruta (name) que tenemos en el archivo urls.py

from django.views.generic import ListView, DetailView, CreateView, DeleteView, UpdateView
from .models import Task
from .forms import TaskForm

# Definición de vistas de las Tareas según las CBV ya creadas
class TaskListView(ListView):
    model = Task
    context_object_name = 'tareas' # ¿Qué plantilla vas a utilizar?
    paginate_by = 10

class TaskDetailView(DetailView):
    model = Task

class TaskCreateView(CreateView):
    model = Task
    form_class = TaskForm
    success_url = reverse_lazy('tareas:lista') # si creas una nueva tarea, al terminar la creación, vuelve a la lista de tareas

class TaskUpdateView(UpdateView):
    model = Task
    form_class = TaskForm
    success_url = reverse_lazy('tareas:lista')

class TaskDeleteView(DeleteView):
    model = Task
    success_url = reverse_lazy('tareas:lista')