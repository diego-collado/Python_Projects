from django.contrib import admin
from .models import Task

# Registro del modelo TASK en el administrador de Django
@admin.register(Task) # forma limpia de mostrar y gestionar tareas en el admin de Django

# Añadimos usabilidad al entorno de administración de Django
class TaskAdmin(admin.ModelAdmin):
    list_display = ("id", "titulo", "completada", "creada") # definimos los campos que se muestran en la tabla 
    list_filter = ("completada", "creada") # posibilidad de filtrado (lateral) en el admin
    search_fields = ("titulo", "descripcion") # activa la barra de búsqueda en el admin