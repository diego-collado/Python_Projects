# tareas/forms.py
from django import forms
from .models import Task

# Más info sobre BootStrap: https://getbootstrap.com/docs/5.0/forms/form-control/

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task # todo se basa en el modelo Tarea, es decir, los campos están unidos a los atributos del modelo
        fields = ['titulo','descripcion','completada'] # campos incluídos, solo se muestran estos campos en la vista
        # si queremos que se muestran TODOS los campos, implementamos: fields = '__all__'
        labels = {
            'titulo':'Título',
            'descripcion':'Descripción',
            'completada': '¿Hecha?',
        } # asociamos el label a cada campo

        # personalización de la renderización en HTML. Django utiliza 'plugins' o widgets para cada tipo de campo
        widgets = {
            'titulo': forms.TextInput(attrs={'class':'form-control'}),
            # attrs= ... --> significa que agregamos atributos HTML, lo cual facilita la utilización de BootStrap o cualquier otro framework CSS
            'descripcion':forms.Textarea(attrs={'rows':4,'class':'form-control'}),
            'completada': forms.CheckboxInput(attrs={'class':'form-check-input'}),
            # se renderiza: <input type="checkbox">, es decir, HTML puro y duro de toda la vida...
        }