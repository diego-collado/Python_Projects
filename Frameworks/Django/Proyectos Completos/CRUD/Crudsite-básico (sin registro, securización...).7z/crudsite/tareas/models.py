from django.db import models

# Creación del modelo TASK
class Task(models.Model):
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    completada = models.BooleanField(default=False)
    creada = models.DateTimeField(auto_now_add=True) # se rellena de forma automática en la creación del registro
    actualizada = models.DateTimeField(auto_now=True) # actualización automática en cada guardado

    # Opciones de configuración de mi App
    class Meta:
        ordering = ['-creada'] # ordenación de forma descendente por fecha de creación (nueva---antigua)
        verbose_name = 'tarea' # nombre de las tareas (en singular) que aparecerán en el administrador de Django
        verbose_name_plural = 'tareas' # lo mismo de antes, pero para "nombre del grupo de tareas"
    
    def __str__(self):
        return self.titulo 
    # devuelve el título de la tarea cuando el objeto se representa como texto, es decir, en el admin de Django, se verá la tarea por título como un string