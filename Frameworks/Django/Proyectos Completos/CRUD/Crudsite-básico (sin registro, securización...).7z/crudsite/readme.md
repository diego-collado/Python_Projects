PASOS A SEGUIR EN UN PROYECTO Y APPs EN DJANGO

1.- Creación de proyecto: 
    django-admin startproject crudsite

2.- Creación de la app de dominio (el gestor de administración):
    python manage.py startapp tareas

3.- Se nos quedará la siguiente estructura:

CRUDSITE/               --> configuración del proyecto, carpeta principal
|
|-- crudsite/           --> app controladora del proyecto completo (zona de administración)
|       |
|       |- __init__.py
|       |- asgi.py
|       |- settings.py
|       |- urls.py
|       |- wsgi.py
|       
|-- tareas/            --> app creada, nueva
|       |- migrations/
|       |- admin.py 
|       |- apps.py
|       |- models.py
|       |- tests.py
|       |- urls.py     --> este archivo se suele crear, no viene dado por defecto
|       |_ views.py
|
|
|-- templates/         --> plantillas para todas las aplicaciones gestionadas por Django
|       |- base.html
|       |- tareas/
|           |_ task_list.html 
|           |_ task_form.html
|           |_ task_detail.html
|           |_ task_confirm_delete.html
|
|
|_ manage.py
|_ readme.md

4.- Configuración de crudsite/settings.py:
    · añadimos la app nuestra al path de todo el proyecto
    · cambiamos hora, idioma, carpeta de plantillas...
    * cambiar en producción la SECRET KEY para evitar hackeos *

5.- Creación de carpeta TEMPLATES, la cual albergará los HTMLs a utilizar

6.- Creación del modelo de tarea, al cual denominamos TASK, con todos los "campos" que se van a utilizar en la futura vista de usuario

7.- Ahora, nos toca aplicar las migraciones, es decir, crear una versión:
    python manage.py makemigrations --> crea un archivo dentro de la carpeta MIGRATIONS, denominado 0001_initial.py
    python manage.py migrate --> revisa todo lo necesario según las APPs instaladas en el propio Django y actualiza la BBDD de Django

8.- Nos toca cambiar y añadir cosas a tareas/admin.py -- es opcional, pero muy recomendable. 

9.- Después de implementar el código, tenemos que crear un usuario superadministrador para poder gestionar todo Django:
    python manage.py createsuperuser

    En este ejemplo, los datos son:
        --> profe      <--
        --> @Aula42025 <--

10.- Ahora, hacemos que la magia se vuelva realidad:
    python manage.py runserver   

11.- Creación de las rutas del proyecto y app (crudsite/urls.py): colocamos las urls donde estará el CRUD.
Conozcamos cada cosa:
    · path(''...) --> define la ruta URL. como es una cadena vacía (''), nos dice que estamos en la 
    raíz de la app
    · views.TaskListView.as_view() --> convertimos la URL en CBV (Class-Based View)
    · as_view() --> convierte la clase en una función para que Django la pueda manejar a la hora de 
    trabajar con la petición HTTP
    · name='lista') --> muestra el listado de elementos, en este caso, es decir, es un alias de la ruta
    · '<int:pk>' --> convertidor de ruta para Django. La ruta espera un número entero, el cual se pasa
    como argumento gracias al parámetro PK que tendremos en nuestra vista. PK significa Primary Key

12.- Ahora, toca crear un nuevo archivo urls.py en nuestra aplicación, el cual va a tener disponible la lista de urls que se podrán ejecutar según cada petición recibida.
Cada vista es manejada según la url que recibe como parámetro.
En un momento dado, cada url se convierte en una clase basada en vistas, o CBV, vistas que Django puede utilizar.

12+1.- Creación del archivo tareas/forms.py, el cual contendrá el formulario (campos) que se verá en las propias vistas de la app. Se crea a partir de una clase formulario propia de Django y (como vimos antes), aplicaremos una configuración (tipo de campo, longitud...), o lo que es lo mismo, tendremos disponible un MODELO.

14.- Creación de las vistas, donde realmente definimos qué vista irá a qué funcionalidad (crear, listar...), es decir, trabajamos directamente con las CBV.

15.- Momento de tocar las templates, o lo que es lo mismo, crear un archivo HTML de toda la vida donde inyectaremos el código necesario para que se plasmen los datos. El primer archivo que tenemos que implementar es templates/base.html
Se va a utilizar BootStrap vía CDN para la creación rápida de estilos.

16.- Creación de la carpeta TAREAS dentro de TEMPLATES, el cual estarán contenidas las plantillas de HTML de cada aplicación. Si tenemos 4 aplicaciones, habrá 4 carpetas diferentes, cada una de ellas con las plantillas que se necesiten para poder ver todo el contenido de la BBDD que tenemos disponible con Django.

17.- Implementación del archivo task_list.html, plantilla para el listado de tareas, la cual está dentro de la carpeta TAREAS de TEMPLATES

18.- Después del archivo anterior, crearemos task_detail.html, task_confirm_delete.html y task_form.html para parametrizar lo mínimo de nuestro CRUD.