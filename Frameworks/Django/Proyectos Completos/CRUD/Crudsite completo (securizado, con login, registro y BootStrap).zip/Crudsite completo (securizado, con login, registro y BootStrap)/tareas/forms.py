from django import forms # Importación del módulo formularios (incluyendo funcionalidades)
from .models import Task # Importación del modelo de nuestra App

# Creamos cómo será nuestro formulario
class TaskForm(forms.ModelForm):
    class Meta: # configuración de metadata, opciones que modificarán el comportamiento de los modelos
        model = Task # cuál es el modelo de trabajo
        fields = ['titulo', 'descripcion', 'completada'] # campos que tengo para cada formulario
        # Son miniaplicaciones HTML, encargadas de gestionar la renderización del HTML y la extracción de datos
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'completada': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
