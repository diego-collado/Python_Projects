from django.urls import path # Importación del módulo de control de paths
from . import views # Importación del módulo de control de vistas

app_name = 'tareas' # Defición del espacio de nombres de nuestra app, es decir, sirve para evitar problemas con las URLs de distintas apps

# Lista de rutas de la app, es decir, la lista de CBV (vista basada en clases)
urlpatterns = [
    path('', views.TaskListView.as_view(), name='lista'),                           # vista completa o listado completo de tareas
    path('crear/', views.TaskCreateView.as_view(), name='crear'),                   # vista formulario de creación de tares
    path('<int:pk>/', views.TaskDetailView.as_view(), name='detalle'),              # vista de detalle de una tarea específica
    path('<int:pk>/editar/', views.TaskUpdateView.as_view(), name='editar'),        # vista de formulario de edición de tarea
    path('<int:pk>/eliminar/', views.TaskDeleteView.as_view(), name='eliminar'),    # vista de confirmación de eliminación de una tarea
]
# <int:pk> nos indica que PK es la que queremos modificar o borra, evitando conflictos y problemas