from django.contrib import admin # Importa la administración de Django para enrutar admin.site.urls
from django.urls import path, include # Importa las funciones para definir rutas (path) y anidar otros archivos de URL (include)
from django.contrib.auth import views as auth_views # Importa las vistas de autenticación que trae Django, utilizando un alias
from django.contrib.auth import logout # Importa la función logout del sistema de auth
from .views import register, logout_get # Importa desde tus vistas locales la función register (vista de registro)

# Lista que contiene todas las rutas del proyecto, donde Django busca esta variable (por convención)
urlpatterns = [
    # Ruta para el panel de administración
    path('admin/', admin.site.urls),
    # Rutas de autenticación
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', logout_get, name='logout'),  # en lugar de path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', register, name='register'),
    # Rutas propias de la App
    path('', include('tareas.urls')),
]