from pathlib import Path # Importa Path para manejar rutas de archivos de forma cómoda y multiplataforma
import os # Importa el módulo os (útil para variables de entorno, rutas, etc.)

BASE_DIR = Path(__file__).resolve().parent.parent # Definición de la carpeta base del proyecto

SECRET_KEY = 'dev-key-not-secret' # Clave secreta que Django usa para firmar cookies, tokens CSRF, etc.
DEBUG = True # Modo debug activado, se muestran errores y toda la información posible
ALLOWED_HOSTS = ['*'] # Lista de hostnames permitidos para servir el sitio. En este caso, se permite cualquier IP/dominio

#Apps instaladas en el proyecto
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'tareas', # app que hemos creado
]

# Middleware que procesan cada petición/respuesta (seguridad, sesión, CSRF, auth, mensajes, protección clickjacking, etc.)
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# Módulo que contiene los patrones de URL raíz del proyecto (crudsite/urls.py)
ROOT_URLCONF = 'crudsite.urls' 

# Configuración del motor de plantillas
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
# Puntos de entrada para servidores:
#    --> Creación de canal de comunicación con el server = ASGI (Daphne, Uvicorn; útil para websockets, async) 
#    --> Creación del puente para trabajar con el server = WSGI (Gunicorn, uWSGI, Apache mod_wsgi…)

WSGI_APPLICATION = 'crudsite.wsgi.application'
ASGI_APPLICATION = 'crudsite.asgi.application'

# Configuración de la BBDD en SQLite3. En producción suele cambiarse a Postgres/MySQL, etc
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Validadores de contraseñas: evitan contraseñas débiles
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Configuraciones comunes
LANGUAGE_CODE = 'es-es' # Idioma por defecto del proyecto: español (España)
TIME_ZONE = 'Europe/Madrid' # Zona horaria del proyecto
USE_I18N = True # Habilita internacionalización (traducciones)
USE_TZ = True # Usa fechas con zona horaria (Django guarda en UTC y ajusta a TIME_ZONE al mostrar)

# Configuración de los archivos estáticos (jpgs, pdf, js...)
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

LOGIN_REDIRECT_URL = 'tareas:lista' # Redirección si el login está OK
LOGOUT_REDIRECT_URL = 'login' # Redirección tras logout
LOGIN_URL = 'login' # URL al que se enviará al usuario cuando un @login_required necesite autenticación

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField' 
# Tipo por defecto para las claves primarias nuevas en modelos (BigAutoField, entero 64 bits autoincremental)