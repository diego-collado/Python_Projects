**************************************************
******** CRUD Tareas (Django + Bootstrap) ********
**************************************************

· Pantalla de login directa (ruta `/login/` y redirección automática para rutas protegidas).
· Logout, entrar y registro visible en la barra superior
· Signup con Bootstrap en /signup/
· CRUD de tareas con vistas genéricas


PASOS A SEGUIR EN UN PROYECTO Y APPs EN DJANGO -------------------------------------------------

1.- Creación de proyecto: django-admin startproject crudsite

2.- Creación de la app de dominio (el gestor de administración): python manage.py startapp tareas

3.- Se nos quedará la siguiente estructura:

CRUDSITE/               --> configuración del proyecto, carpeta principal
|
|-- crudsite/           --> app controladora del proyecto completo (zona de administración)
|       |
|       |- __init__.py  --> marca la carpeta donde se encuentre como un paquete de Python
|       |- asgi.py      --> ASGI (Asynchronous Server Gateway Interface), compatible con Websockets 
|       |- urls.py      --> define el mapa de navegación, conecta las URLs con las vistas (views)
|       |- wsgi.py      --> configura la interfaz WSGI (Web Server Gateway Interface), ejecutando en los servidores web
|       |- settings.py  --> contiene toda la configuración de tu proyecto Django (
|                             => Qué apps están instaladas (INSTALLED_APPS)
|                             => Cómo se conecta la base de datos (DATABASES)
|                             => Dónde están las plantillas (TEMPLATES)
|                             => Idioma, zona horaria, archivos estáticos (STATIC_URL)
|                             => Seguridad y claves (SECRET_KEY, DEBUG, ALLOWED_HOSTS)
|       
|-- tareas/            --> app: Crud de gestión de tareas
|       |- migrations/ --> contiene los archivos de migraciones de BBDD, es decir, los cambios y backups de esos cambios
|       |- admin.py    --> registra los modelos para que aparezcan en el panel de administración de Django (/admin)
|       |- apps.py     --> contiene la configuración de la app que se está creando
|       |- models.py   --> define las tablas de BBDD (modelos): class representa 1 tabla SQL y cada atributo, 1 columna
|       |- tests.py    --> sirve para escribir tests automáticos (pruebas)
|       |- urls.py     --> define las rutas específicas de la app
|       |_ views.py    --> contiene las vistas, la lógica que decide qué mostrar o hacer cuando se visita una URL
|
|
|-- templates/                           --> carpeta que contiene todas las plantillas HTML (renderización de páginas)
|       |- base.html                     --> plantilla principal del proyecto, que define una estructura común
|       |      
|       |- tareas/                       --> plantillas HTML específicas del módulo de tareas (CRUD)
|       |   |_ task_list.html            --> muestra la lista de tareas (la vista principal)
|       |   |_ task_form.html            --> formulario para crear o editar tareas.
|       |   |_ task_detail.html          --> muestra los detalles de una tarea individual
|       |   |_ task_confirm_delete.html  --> página de confirmación antes de borrar una tarea
|       |
|       |- registration/                 --> plantillas HTML relacionadas con la autenticación
|           |_ login.html                --> muestra el formulario de inicio de sesión
|           |_ logged_out.html           --> mostraría la pantalla de finalización (se redirecciona al login)
|           |_ signup.html               --> muestra el formulario de registro de nuevos usuarios
|           |_ register.html             --> muestra el formulario de registro de nuevos usuarios
|
|
|_ manage.py            --> es el control central de Django, sirve para ejecutar comandos administrativos del proyecto
|_ readme.md            --> archivo de documentación (en formato Markdown .md)
|_ db.sqlite3           --> base de datos del proyecto
|
|
|-- static/             --> carpeta donde se guardan archivos estáticos (no cambian en el tiempo ni dependen de la BBDD)
        |
        |- img/         --> carpeta donde se guardan las imágenes que se utilizarán para logotipos y otras imágenes
            |_ logo.png --> imagen del logo, a insertar en el HTML


4.- Configuración de crudsite/settings.py:
    · añadimos la app nuestra al path de todo el proyecto
    · cambiamos hora, idioma, carpeta de plantillas...
    * cambiar en producción la SECRET KEY para evitar hackeos *

5.- Creación de carpeta TEMPLATES, la cual albergará los HTMLs a utilizar

6.- Creación del modelo de tarea, al cual denominamos TASK, con todos los "campos" que se van a utilizar en la futura vista de usuario

7.- Ahora, nos toca aplicar las migraciones, es decir, crear una versión:
    python manage.py makemigrations --> crea un archivo dentro de la carpeta MIGRATIONS, denominado 0001_initial.py
    python manage.py migrate --> revisa todo lo necesario según las APPs instaladas en el propio Django y actualiza la BBDD de Django

8.- Nos toca cambiar y añadir cosas a tareas/admin.py -- es opcional, pero muy recomendable. 

9.- Después de implementar el código, tenemos que crear un usuario superadministrador para poder gestionar todo Django:
    python manage.py createsuperuser

    En este ejemplo, los datos son:
        --> profe      <--
        --> @Aula42025 <--

10.- Ahora, hacemos que la magia se vuelva realidad:
    python manage.py runserver   

11.- Creación de las rutas del proyecto y app (crudsite/urls.py): colocamos las urls donde estará el CRUD.
Conozcamos cada cosa:
    · path(''...) --> define la ruta URL. como es una cadena vacía (''), nos dice que estamos en la 
    raíz de la app
    · views.TaskListView.as_view() --> convertimos la URL en CBV (Class-Based View)
    · as_view() --> convierte la clase en una función para que Django la pueda manejar a la hora de 
    trabajar con la petición HTTP
    · name='lista') --> muestra el listado de elementos, en este caso, es decir, es un alias de la ruta
    · '<int:pk>' --> convertidor de ruta para Django. La ruta espera un número entero, el cual se pasa
    como argumento gracias al parámetro PK que tendremos en nuestra vista. PK significa Primary Key

12.- Ahora, toca crear un nuevo archivo urls.py en nuestra aplicación, el cual va a tener disponible la lista de urls que se podrán ejecutar según cada petición recibida.
Cada vista es manejada según la url que recibe como parámetro.
En un momento dado, cada url se convierte en una clase basada en vistas, o CBV, vistas que Django puede utilizar.

12+1.- Creación del archivo tareas/forms.py, el cual contendrá el formulario (campos) que se verá en las propias vistas de la app. Se crea a partir de una clase formulario propia de Django y (como vimos antes), aplicaremos una configuración (tipo de campo, longitud...), o lo que es lo mismo, tendremos disponible un MODELO.

14.- Creación de las vistas, donde realmente definimos qué vista irá a qué funcionalidad (crear, listar...), es decir, trabajamos directamente con las CBV.

15.- Momento de tocar las templates, o lo que es lo mismo, crear un archivo HTML de toda la vida donde inyectaremos el código necesario para que se plasmen los datos. El primer archivo que tenemos que implementar es templates/base.html
Se va a utilizar BootStrap vía CDN para la creación rápida de estilos.

16.- Creación de la carpeta TAREAS dentro de TEMPLATES, el cual estarán contenidas las plantillas de HTML de cada aplicación. Si tenemos 4 aplicaciones, habrá 4 carpetas diferentes, cada una de ellas con las plantillas que se necesiten para poder ver todo el contenido de la BBDD que tenemos disponible con Django.

17.- Implementación del archivo task_list.html, plantilla para el listado de tareas, la cual está dentro de la carpeta TAREAS de TEMPLATES

18.- Después del archivo anterior, crearemos task_detail.html, task_confirm_delete.html y task_form.html para parametrizar lo mínimo de nuestro CRUD.

* - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * 
AMPLIACIÓN DE LA APLICACIÓN: AUTENTICACIÓN (LOGIN/LOGOUT) Y PERMISOS DE USUARIO
* - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * 
19.- En este caso, queremos y necesitamos que cada usuario sólo vea y gestione sus propias tareas:
    --> Añadiremos un campo owner al modelo
    --> Obligaremos a iniciar sesión para acceder al CRUD
    --> Restringiremos la edición y borrado de propietarios (owners)

20.- Creamos un modelo de propietario (el famoso owner) en nuestro archivo tareas/models.py

21.- Ahora toca hacer la migración con "cuidaito"... Si NO tenemos datos, la migración se hace directamente... En caso contrario, debemos hacer una migración temporal mediante un usuario administrador, es decir, debemos disponer de un usuario por defecto.
Al no tener datos, la migración la hacemos con los comandos:
    - python manage.py makemigrations
    - python manage.py migrate

Si se produce el error que hemos comentado, podemos añadir null=True en nuestro código para que momentaneamente, permitamos la creación y manejo de campos nulos en la BBDD para hacer la backup.
Esto permitirá que se creen las migraciones sin tener que asignar valores a los datos ya existentes.

22.- Añadiremos las urls de autenticación a Django en nuestro campo urls.py.

23.- Se retocan las views añadiendo:
    --> carga de bibliotecas de Django para gestión de usuarios y mensajes de error
    --> creación de una vista por owner
    --> creación de filtrado y ordenación de la lista de tareas, controlando que estén correctas y que pertenezcan al usuario que tiene abierta la sesión
    --> creación de una nueva paginación automática, de forma que tendremos disponible un control de errores de paginación, evitando algún que otro problema de inyección
    --> control de errores si asignamos el número de página directamente en la URL:
    /articulos/?page_size=33 --> no existe, devuelve 10 (por defecto, 10 elementos por página)
    
Cada usuario tiene un información determinada, es decir, tiene una información personalizada al contexto, la cual se enviará la HTML
En lo relativo al contexto, incluimos cosas como:
    -> nombre del modelo
    -> página actual (paginación)
    -> filtros o formularios que este usuario tiene disponibles

args en Python: la función tiene un número variable de parámetros 
    --> def funcion(*args)
kwags en Python: es una convención, podemos utilizar **daigual, lo que nos permite dar un nombre a cada argumento de entrada, pudiendo acceder a ellos dentro de la función a través de un diccionario 
    --> def funcion (**kwargs )
    CLAVE - VALOR

En la función que nos va a crear el contexto, tenemos: params = self.request.GET.copy()
Se crea una copia de la URL: /articulos/?q=django&page=2&order=asc, la cual contendra:
    {'q':'django',
    'page':2,
    'order':'asc'}

Al resto de las clases que tenemos en views.py, las tenemos que añadir LoginRequiredMixin y OwnerQuerysetMixin, para hacerlas dependientes de la autenticación

En la clase TaskCreateView, hacemos dependiente la creación de nuevas tareas siempre y cuando tengamos permiso para ello, es decir, que obligamos al usuario a que esté logueado y, además, que tenga privilegios para poder crear tareas. En el caso del update y el delete, tenemos que hacerlo dependiente del usuario

Creamos el objeto OwnerRequiredMixin, para gestionar todo lo relativo a testeo, o lo que es lo mismo, si el usurio no está logueado o lo hace de forma incorrecta, le lanzamos un error 403 (Forbidden)

24.- Creamos un login, el cual deberá estar en la ruta templates/registration/login.html

25.- Creamos el logout, en la misma ruta anterior

26.- Insertamos el control de mensajes para que la aplicación nos pueda informar acerca de errores o cualquier información importante. Para ello, actualizamos con el código conveniente el archivo templates/base.html.
Debemos tener en cuenta que el middleware debería estar cargado ya en crudsite/settings.py

27.- Ahora, nos ponemos manos a la obra con los filtros, la ordenación y la paginación avanzada. Se añaden los controles en la plantilla y se mejora la paginación. Vamos a tocar los controles en el archivo templates/tareas/task_list.html.

28.- En crudsite/settings.py, debemos añadir las redirección tras el login/logout para la mejora y eficiencia de la UX.

 --> POSTERIORMENTE, SE HAN INCLUÍDO LÍNEAS PARA REGISTRO DE NUEVOS USUARIOS Y TODO LO RELATIVO A LA VISUALIZACIÓN CON EL FRAMEWORK DE CSS BOOTSTRAP <-- 

* - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * 
ARRANQUE Y PRIMERAS ACCIONES
* - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * - * 

A.- Creación de entorno virtual
    Linux:
        python -m venv .venv
        source .venv/bin/activate  
    Windows: 
        .venv\Scripts\activate

B.- En la consola:
    pip install -r requirements.txt
    python manage.py migrate
    python manage.py runserver