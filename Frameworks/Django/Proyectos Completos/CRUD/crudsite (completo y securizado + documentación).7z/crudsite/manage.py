#!/usr/bin/env python
'''!/usr/bin/env python --> 
Se denomina shebang: dice al SSOO que ejecute este archivo con el intérprete de Python que encuentre 
primero en el PATH (útil en Linux/macOS). 
En Windows suele ignorarse porque se llama al script con python manage.py
'''

import os # módulo estándar os para interactuar con el sistema y variables de entorno
import sys # módulo acceder a argumentos de shell y otras utilidades del intérprete

# Lógica principal: define la variable de entorno solo si no existe ya (por eso setdefault)
def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'crudsite.settings')
    from django.core.management import execute_from_command_line # intérprete de comandos (migrate, run...)
    execute_from_command_line(sys.argv) # ejecuta el comando indicado en la terminal, usando los argumentos escritos despues del manage.py

if __name__ == '__main__':
    main()
