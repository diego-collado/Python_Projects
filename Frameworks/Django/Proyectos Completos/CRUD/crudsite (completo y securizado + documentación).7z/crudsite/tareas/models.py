from django.db import models # Importación del módulo de gestión de modelos de la BBDD
from django.conf import settings # Importación de la configuración de Django

# Declaración del modelo Tarea, heredado de models.Model
class Task(models.Model):
    # cómo se gestiona el usuario (comportamientos en borrado, autenticaciones...)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, # dejamos que Django controle el tema de autenticaciones
        on_delete=models.CASCADE, # borrado en cascada, se borra absolutamente todo lo que tenga ese usuario
        related_name='tasks' # todo es relativo a esta App
    )

    # Cómo son los campos y condiciones de los mismos
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    completada = models.BooleanField(default=False)
    creada = models.DateTimeField(auto_now_add=True)
    actualizada = models.DateTimeField(auto_now=True)

    class Meta: # Metadata
        ordering = ['-creada'] # orden por defecto de las consultas. En este caso el orden es DESC
        # nombres legibles desde admin y el resto de UI (User Interface -- la pantalla que ve el usuario)
        verbose_name = 'tarea' 
        verbose_name_plural = 'tareas'

    # Método mágico de Python: representa el texto del objeto, mostrándolo en la UI como título
    def __str__(self):
        return self.titulo

# 
class LoginEvent(models.Model):
    # Definición de los valores que guardará la BD
    LOGIN = 'login' 
    LOGOUT = 'logout'

    ACTIONS = [(LOGIN, 'Login'), (LOGOUT, 'Logout')] 
    # lista de opciones para el campo action. Tiene el valor que se guarda y la etiqueta legible

    # Enlace de eventos con usuarios
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='login_events')
    action = models.CharField(max_length=10, choices=ACTIONS) # guardamos la acción: 'login' o 'logout', donde choices fuerza que el valor sea una de las opciones y, en formularios/admin, muestra un desplegable.
    ip = models.GenericIPAddressField(null=True, blank=True) # guarda IPv4 o IPv6, de modo que con null=True permite NULL en BD y con blank=True permite dejarlo vacío en formularios/admin
    user_agent = models.TextField(blank=True) # guarda el User-Agent completo del browser, donde blank=True permite campo vacío
    created_at = models.DateTimeField(auto_now_add=True) # se guarda automáticamente la fecha/hora al crear el registro, no variando aunque se actualice

    class Meta: # Metadata
        ordering = ['-created_at'] # ordenación por eventos más recientes primero

    # Método mágico para muestra del objeto en el admin/shell, donde se usa f-string con formato de fecha YYYY-MM-DD HH:MM
    def __str__(self):
        return f"{self.user} {self.action} @ {self.created_at:%Y-%m-%d %H:%M}"