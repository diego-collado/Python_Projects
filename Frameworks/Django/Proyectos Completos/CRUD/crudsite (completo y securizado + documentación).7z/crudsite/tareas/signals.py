# Control de mensajes por parte de Django
from django.contrib.auth.signals import user_logged_in, user_logged_out # mensajes de autenticación
from django.dispatch import receiver # Importación del decorador @receiver que conectará funciones con su respectivo mensaje
from django.contrib import messages # Importación del módulo de gestión de mensajes de Django
from .models import LoginEvent # Importación del módulo donde se gestiona el modelo de guardado de registro

@receiver(user_logged_in) # función a ejecutar cada vez que se dispare la señal de login
def show_login_message(sender, user, request, **kwargs):
# modelo_que_envía_la_señal, usuario_que_está_logueado, petición_HTTP, otros_parámetros
    messages.success(request, f"¡¡Bienvenido, {user.username}!! Has iniciado sesión correctamente")
    # Utilizamos el sistema de mensajes de Django

@receiver(user_logged_out) # función a ejecutar cada vez que se dispare la señal de logout
def show_logout_message(sender, user, request, **kwargs):
    messages.info(request, "Acabas de cerrar sesión... ¡¡Hasta pronto!!")

def _get_ip(request): # función para obtención de la IP del cliente
    # Respeta X-Forwarded-For si hay proxy/reverse proxy
    xff = request.META.get('HTTP_X_FORWARDED_FOR') # contiene las cabeceras HTTP, por lo que si la app está detrás de proxy/balanceador, la IP real se pasa en HTTP_X_FORWARDED_FOR
    if xff:
        return xff.split(',')[0].strip()
    return request.META.get('REMOTE_ADDR') # Si no existe proxy/balanceador, utiliza la IP directa del cliente

@receiver(user_logged_in) # función que será llamada cada vez que un usuario se loguee
def on_login(sender, user, request, **kwargs):
    LoginEvent.objects.create(
        user=user, # usuario autenticado
        action=LoginEvent.LOGIN,
        ip=_get_ip(request), # IP obtenida con _get_ip(request)
        user_agent=request.META.get('HTTP_USER_AGENT','') # el navegador o cliente (HTTP_USER_AGENT)
    )

@receiver(user_logged_out) # función que será llamada cada vez que un usuario cierre sesión
# Comprueba que user existe y está autenticado (en algunos casos user puede ser None). Se registra el evento de logout
def on_logout(sender, user, request, **kwargs):
    if user and user.is_authenticated:
        LoginEvent.objects.create(
            user=user,
            action=LoginEvent.LOGOUT,
            ip=_get_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT','')
        )