from django.apps import AppConfig # Importación del módulo de configuración de mi App

# Creamos una clase que será la tabla completa de la BBDD
class TareasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tareas'

    # Método ejecutado automáticamente cuando Django termina de cargar la app
    def ready(self):
        from . import signals  # noqa: F401
# Se conectan los receptores, aunque no se inicialice signals. 
# El código noqa evita el marcado del import como no utilizado