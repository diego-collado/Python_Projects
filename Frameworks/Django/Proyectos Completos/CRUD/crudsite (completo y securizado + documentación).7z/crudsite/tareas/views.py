# ARCHIVO DE VISTAS BASADAS EN CLASES (CBV)

from django.contrib.auth.mixins import LoginRequiredMixin # Restricciones de acceso por autenticación
from django.urls import reverse_lazy # Importación del módulo para generar la URL inversa, es decir, el "rollback"
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView # Importación de las vistas genéricas
from .models import Task, LoginEvent # Importación del modelo Tareas y eventos login
from .forms import TaskForm # Importación del modelo de formulario (personalizado)
from django.views.generic import TemplateView, View # Importa del módulo de control del sistema de vistas genéricas basadas en clases (CBV) 
from django.http import JsonResponse # Importación de módulo de creación de respuestas HTTP en formato JSON, muy usada para vistas tipo API o peticiones AJAX desde el frontend.
# Se comporta como un HttpResponse, pero convierte automáticamente los diccionarios Python en JSON
from django.utils import timezone # Importación del módulo para manejar fechas y horas con soporte de zona horaria (timezones)
from django.db.models import Count # función de agregación del ORM de Django que cuenta registros
from django.db.models.functions import TruncDay, TruncHour # Importación de funciones para truncado (agrupación por día/hora)
import platform, sys # Importación de módulos estándar de Python (no de Django) sobre información del sistema operativo e información del intérprete de Python
from django.conf import settings # Importación del módulo de control de acceso al objeto global de configuración de Django
from django import get_version as dj_version # Importa la función get_version() de Django, pero la renombra localmente (para saber qué versión de Django se está ejecutando)
import psutil # Importación del módulo que gestiona las métricas de CPU/RAM/Disco

# Vista que muestra la lista de objetos de tipo Tarea
class TaskListView(LoginRequiredMixin, ListView): # aseguramos que el usuario vea unicamente su lista
    model = Task
    template_name = 'tareas/task_list.html' # qué plantilla se va a renderizar al llamar a esta función
    context_object_name = 'tareas' # nombre de las tareas que estarán disponibles para la plantilla

    # Filtrado de tareas para que cada usuario SOLO vea sus propias tareas
    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)
        # self.request.user --> usuario actual autenticado

# Vista que muestra los detalles de un único objeto
class TaskDetailView(LoginRequiredMixin, DetailView):
    model = Task
    template_name = 'tareas/task_detail.html'
    context_object_name = 'tarea'

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

# Vista que muestra el formulario de creación de un nuevo objeto de tipo tarea
class TaskCreateView(LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'tareas/task_form.html'
    success_url = reverse_lazy('tareas:lista') # qué voy a ver cuando termino de crear la tarea... se redirecciona a la lista de tareas

    # El método se ejecutará cuando el formulario sea válido
    def form_valid(self, form):
        form.instance.owner = self.request.user # el propietario es el usuario actual logueado
        return super().form_valid(form) # retorno al guardado "original"

# Vista que muestra el formulario de modificación de un objeto de tipo Tarea
class TaskUpdateView(LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'tareas/task_form.html'
    success_url = reverse_lazy('tareas:lista')

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

# Vista que muestra el formulario de confirmación de eliminación
class TaskDeleteView(LoginRequiredMixin, DeleteView):
    model = Task
    template_name = 'tareas/task_confirm_delete.html'
    success_url = reverse_lazy('tareas:lista')

    def get_queryset(self):
        return Task.objects.filter(owner=self.request.user)

# Vista que muestra el dashboard (si el usuario en cuestión está autenticado)
class DashboardView(LoginRequiredMixin, TemplateView):
    template_name = 'dashboard.html' # nombre del template que se renderizará para esta vista

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # KPIs rápidos del usuario, contadores clave 
        user = self.request.user # se toma el usuario autenticado (petición actual) para filtrar sus datos
        # KPIs medibles, como total de tareas, tareas hechas/pendientes, número de logins realizados...
        ctx['kpi_total_tasks'] = Task.objects.filter(owner=user).count()
        ctx['kpi_done_tasks'] = Task.objects.filter(owner=user, completada=True).count()
        ctx['kpi_pending_tasks'] = Task.objects.filter(owner=user, completada=False).count()
        ctx['kpi_total_logins'] = user.login_events.filter(action=LoginEvent.LOGIN).count()
        return ctx
    
# Vista basada en clase que devuelve JSON para un gráfico de logins por día (del usuario autenticado)
class LoginDailyAPI(LoginRequiredMixin, View):
    def get(self, request):
        days = int(request.GET.get('days', 30)) # días por defecto: 30
        since = timezone.now() - timezone.timedelta(days=days-1) # se calcula la fecha/hora inicial para cubrir days días incluyendo hoy        
        
        # Filtra eventos de login del usuario actual
        qs = LoginEvent.objects.filter(user=request.user, action=LoginEvent.LOGIN, created_at__date__gte=since.date())
        # grupa por día im redondeo a medianoche y lo guarda como day, fija la agrupación, cuenta eventos por día y crea un orden ascendente por fecha
        data = (
            qs.annotate(day=TruncDay('created_at'))
            .values('day')
            .annotate(count=Count('id'))
            .order_by('day')
        )
        
        labels = [d['day'].date().isoformat() for d in data] # creación etiquetas (YYYY-MM-DD) para el gráfico a partir del campo day
        values = [d['count'] for d in data] # extracción de los conteos por día en el mismo orden
        
        # Devolución del JSON listo para crear el gráfico (arrays paralelos, labels y values)
        return JsonResponse({'labels': labels, 'values': values})

# Vista que muestra los logins del usuario agrupados por hora (últimas n horas), dentro de un rango reciente (por defecto, las últimas 24 horas)
class LoginHourlyAPI(LoginRequiredMixin, View):
    def get(self, request):
        # cálculo de horas
        hours = int(request.GET.get('hours', 24)) # se obtiene el parámetro hours (?hours=12), aunque si no está presente, usa el valor por defecto 24
        since = timezone.now() - timezone.timedelta(hours=hours) # calcula el tiempo desde el cual se quiere analizar los logins, restando la cantidad de horas activas según la fecha/hora actual (dependiente de timezone)

        # construcción de un queryset de solo los eventos de login del usuario en las últimas n horas
        qs = LoginEvent.objects.filter(user=request.user, action=LoginEvent.LOGIN, created_at__gte=since)
        # procesamiento del queryset para agrupar los eventos por hora
        data = (
            qs.annotate(h=TruncHour('created_at'))
            .values('h')
            .annotate(count=Count('id'))
            .order_by('h')
        )
        labels = [timezone.localtime(d['h']).strftime('%d/%m %Hh') for d in data] #se construye la lista de etiquetas (fechas y horas formateadas) para el gráfico       
        values = [d['count'] for d in data] # se extrae solo el número de logins (count) de cada grupo horario

        # devuelve un JSON con los datos preparados, ideal para consumir desde JS (cualquier framework JS)
        return JsonResponse({'labels': labels, 'values': values})
        # ejemplo de JSON {"labels": ["09/10 14h", "09/10 15h", "09/10 16h"],"values": [2, 4, 1]}

# Vista que muestra un pequeño resumen (KPI) de tareas del usuario autenticado, para gráfica rápida en la dashboard
class TasksSummaryAPI(LoginRequiredMixin, View): 
    # como siempre, solo usuarios autenticados pueden acceder y responder a la solicitud GET
    def get(self, request):
        user = request.user
        total = Task.objects.filter(owner=user).count() # consulta la BBDD para contar todas las tareas (Task) del usuario actual
        done = Task.objects.filter(owner=user, completada=True).count() # consulta de nuevo a la BBDD, filtrando por las tareas completadas (completada=True) del mismo usuario
        pending = total - done # calcula las tareas pendientes restando las hechas del total
        
        # JSON devuelto con 3 claves ("total" → número total de tareas del usuario / "hechas" → número de tareas completadas / "pendientes" → número de tareas sin completar)
        return JsonResponse({'total': total, 'hechas': done, 'pendientes': pending})

# Vista  (protegida por autenticación) que calcula y muestra información sobre el entorno del servidor Django (versiones, base de datos, zona horaria), midiendo tiempo activo del proceso de servidor sin usar librerías externas
class SystemInfoAPI(LoginRequiredMixin, View): # solo usuarios logueados pueden pedir la información del sistema
    def get(self, request):
        # Uptime (tiempo activo del server) del proceso (sin psutil): diferencia desde el arranque del server Django
        started = getattr(settings, 'SERVER_STARTED_AT', None) # obtenemos el cuándo se inició el servidor Django por primera vez
        
        # Si SERVER_STARTED_AT no existe aún (None), se toman los datos una vez que se arranque el server
        if not started:
            started = timezone.now()
            settings.SERVER_STARTED_AT = started
            uptime = timezone.now() - started
            info = {
            'django_version': dj_version(),
            'python_version': sys.version.split()[0],
            'platform': platform.platform(),
            'database_engine': settings.DATABASES['default']['ENGINE'],
            'timezone': settings.TIME_ZONE,
            'uptime_seconds': int(uptime.total_seconds()),
            }
        return JsonResponse(info) # devuelve la respuesta JSON con el contenido del diccionario info

# Vista que devuelve métricas en vivo del sistema (CPU, RAM, Disco, proceso actual)
class SystemLiveAPI(LoginRequiredMixin, View):
    def get(self, request):
        vm = psutil.virtual_memory() # información sobre la memoria RAM del sistema
        disk = psutil.disk_usage('/') # información sobre el uso del disco en la ruta raíz /
        proc = psutil.Process() # información sobre el proceso donde está runeado Django (consumo de CPU, memoria, archivos abiertos, etc)
        data = {
            'cpu_percent': psutil.cpu_percent(interval=None), # porcentaje de uso total de CPU en el sistema en el momento de la llamada
            'memory_percent': vm.percent, # % de RAM usada
            'disk_percent': disk.percent, # % de espacio usado en disco
            'proc_mem_mb': round(proc.memory_info().rss / 1024 / 1024, 1), # % uso de memoria del proceso actual de Django en MB
        }
        return JsonResponse(data)