# ARCHIVO DE ADMINISTRACIÓN DEL CRUD
from django.contrib import admin # Importa todo el panel de gestión de backend
from .models import Task # Importa el modelo de nuestra app

# Creación de todo lo relativo a la gestión de mi BBDD (campos de cada registro)
@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('id', 'titulo', 'owner', 'completada', 'creada') # qué vemos en la lista
    list_filter = ('completada', 'creada') # cómo podemos filtrar la lista
    search_fields = ('titulo', 'descripcion') # qué campos son los que utilizamos en las búsquedas