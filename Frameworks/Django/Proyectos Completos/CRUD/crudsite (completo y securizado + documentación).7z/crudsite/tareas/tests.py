from django.test import TestCase
from django.urls import reverse
from .models import Task

# Create your tests here.
class TaskTest(TestCase):
    def setUp(self):
        Task.objects.create(titulo='Probar', descripcion='Demo')
    
    def test_listado_responde(self):
        r = self.client.get(reverse('tareas:lista'))
        self.assertEqual(r.status_code,200)
        self.assertContains(r,'Tareas')
    
    def test_crear_tarea(self):
        r = self.client.post(reverse('tareas:crear'),{
            'titulo': 'Nueva', 'descripcion': 'x', 'completada': False
        })
        self.assertEqual(r.status_code,302)
        self.assertEqual(Task.objects.count(),2)