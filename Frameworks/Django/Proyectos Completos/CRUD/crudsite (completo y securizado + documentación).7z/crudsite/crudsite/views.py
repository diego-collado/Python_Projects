# crudsite/views.py
from django.contrib.auth.forms import UserCreationForm # Importa el formulario de registro estándar de Django
from django.contrib.auth import login as auth_login, logout as auth_logout
# Importa las funciones de login y logout, pero las renombra como auth_login y auth_logout para evitar colisiones de nombres

from django.shortcuts import render, redirect
# Importa atajos para renderizar plantillas (render) y redireccionar a otra URL (redirect)

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        # Se crea una instancia del formulario con los datos enviados por el usuario (request.POST) para validarlos
        
        # Comprobación de si el formulario pasa todas las validaciones (usuario único, contraseñas válidas y coincidentes, etc.)
        if form.is_valid():
            user = form.save() # Crea el nuevo usuario en la base de datos y devuelve el objeto User creado
            auth_login(request, user) # Autentica al usuario recién creado
            return redirect('tareas:lista')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})
# Renderiza la plantilla registration/register.html pasando en el contexto el formulario (vacío o con errores/valores) bajo la clave 'form'

# Cierre de sesión
def logout_get(request):
    auth_logout(request)
    return redirect('login')