# Archivo: test_weather.py
