# Archivo: weather.py
