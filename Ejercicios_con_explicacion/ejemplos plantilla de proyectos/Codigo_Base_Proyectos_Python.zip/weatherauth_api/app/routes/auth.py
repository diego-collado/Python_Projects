# Archivo: auth.py
