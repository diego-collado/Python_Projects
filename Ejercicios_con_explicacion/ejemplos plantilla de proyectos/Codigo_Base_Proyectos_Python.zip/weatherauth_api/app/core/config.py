# Archivo: config.py
