# Archivo: task_schema.py
